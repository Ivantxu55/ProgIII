package datos;

public enum TipoTarjeta{
	VISA, MASTERCARD, SALDO;
}
