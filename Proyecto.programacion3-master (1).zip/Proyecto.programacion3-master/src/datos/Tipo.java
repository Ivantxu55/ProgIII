package datos;

public enum Tipo {
	Concierto, Festival;
}
