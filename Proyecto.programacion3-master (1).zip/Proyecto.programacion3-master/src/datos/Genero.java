//IAG Google Bard
//FILE: ivan.casado-opendeusto.txt
//ADAPTADO

package datos;

public enum Genero {
    BLUES,
    ELECTRONICA,
    HIP_HOP,
    METAL,
    REGGAE,
    REGGAETON,
    FOLK,
    CLASICA,
    LATINA,
    POP, 
    ROCK, 
    DANCE, 
    JAZZ, 
    TRAP, 
    DISCO;
}
