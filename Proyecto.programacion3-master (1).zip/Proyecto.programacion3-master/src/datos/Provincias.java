package datos;

public enum Provincias {
	ALAVA, VIZCAYA, GIPUZKOA;
}
